package com.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection conn = DatabaseUtil.getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                "SELECT * FROM users WHERE username = ? AND password = ?"
            );
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // ✅ Login successful - create session
                HttpSession session = request.getSession();
                session.setAttribute("username", username);

                // ✅ Create cookie to remember user
                Cookie userCookie = new Cookie("username", username);
                userCookie.setMaxAge(60 * 60 * 24 * 7); // 1 week
                response.addCookie(userCookie);

                // ✅ Store theme preference in a cookie (optional)
                Cookie themeCookie = new Cookie("theme", "dark");
                themeCookie.setMaxAge(60 * 60 * 24 * 30); // 30 days
                response.addCookie(themeCookie);

                // ✅ Redirect to stock management page
                response.sendRedirect("stockManagement");

            } else {
                // ❌ Login failed
                response.setContentType("text/html");
                response.getWriter().println("<h3>Invalid credentials. Please try again.</h3>");
                response.getWriter().println("<a href='login.html'>Back to Login</a>");
            }

        } catch (SQLException e) {
            response.setContentType("text/html");
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }
}
