package com.example;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/stockManagement")
public class StockManagementServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.html");
            return;
        }

        // Retrieve theme from cookies
        Cookie[] cookies = request.getCookies();
        String theme = "default";
        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("theme".equals(c.getName())) {
                    theme = c.getValue();
                }
            }
        }

        try (Connection conn = DatabaseUtil.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM stock");

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h2>Stock List (Theme: " + theme + ")</h2>");
            out.println("<a href='addStock.html'>Add New Item</a><br><br>");
            out.println("<table border='1'><tr><th>Name</th><th>Quantity</th><th>Price</th><th>Actions</th></tr>");
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getString("product_name") + "</td>");
                out.println("<td>" + rs.getInt("quantity") + "</td>");
                out.println("<td>" + rs.getDouble("price") + "</td>");
                out.println("<td><a href='updateStock?id=" + rs.getInt("id") + "'>Update</a> | " +
                        "<a href='deleteStock?id=" + rs.getInt("id") + "'>Delete</a></td>");
                out.println("</tr>");
            }
            out.println("</table>");

        } catch (SQLException e) {
            response.getWriter().println("Database error.");
        }
    }
}
